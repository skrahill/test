# Demo code

<div class="banner intro">
    <div class="default-text"></div>
    <div class="vendor-logo gs-logo"></div>
    <div class="vendor-logo c-sharp-logo"></div>
    <div class="vendor-logo java-logo"></div>
    <div class="vendor-logo python-logo"></div>
</div>

## About

Please locate the `demos` folder in your `ghostpdl` source code download from the [GhostPDL repository] to find sample code demonstrating the language bindings in action.


[Ghostscript releases]: https://ghostscript.com/download/gpdldnld.html
[GhostPDL repository]: https://github.com/ArtifexSoftware/ghostpdl
